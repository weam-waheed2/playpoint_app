<?php if (isset($component)) { $__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Header::class, []); ?>
<?php $component->withName('header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

    <!-- Main Content Wrapper -->
    <main class="main-content w-full px-[var(--margin-x)] pb-8">
      <div
        class="mt-8 grid grid-cols-1 gap-3 sm:mt-3 sm:gap-5 lg:mt-3 lg:gap-3"
      >
      <?php if(session('status-alert')): ?>
        <div class="alert flex rounded-lg bg-error px-4 py-4 text-white sm:px-5 sess_msg">
        <?php echo e(session('status-alert')); ?>

        </div>
        <?php elseif(session('status-success')): ?>
        <div class="alert flex rounded-lg bg-success px-4 py-4 text-white sm:px-5 mb-3 sess_msg">
          <?php echo e(session('status-success')); ?>

        </div>
        <?php else: ?>

        <?php endif; ?>
        
          <div class="flex items-center justify-between">
              <h2 class="text-base font-medium tracking-wide text-slate-700 line-clamp-1 dark:text-navy-100">
              User Tracker
              </h2>
              <div class="flex">
                <div class="flex items-center" x-data="{isInputActive:false}">
            
                </div>

              </div>
            </div>

        <div class="card">
          <div class="is-scrollbar-hidden min-w-full overflow-x-auto">
            <table class="is-hoverable w-full text-left">
              <thead>
                <tr>
                  <th class="whitespace-nowrap rounded-tl-lg bg-slate-200 px-4 py-3 font-semibold uppercase text-slate-800 dark:bg-navy-800 dark:text-navy-100 lg:px-5">
                    #
                  </th>
                  <th class="whitespace-nowrap bg-slate-200 px-4 py-3 font-semibold uppercase text-slate-800 dark:bg-navy-800 dark:text-navy-100 lg:px-5">
                    Transaction Type
                     </th>
                  <th class="whitespace-nowrap bg-slate-200 px-4 py-3 font-semibold uppercase text-slate-800 dark:bg-navy-800 dark:text-navy-100 lg:px-5">
                   USER ID
                  </th>
                   <th class="whitespace-nowrap bg-slate-200 px-4 py-3 font-semibold uppercase text-slate-800 dark:bg-navy-800 dark:text-navy-100 lg:px-5">
                   Coin
                  </th>
                  <th class="whitespace-nowrap bg-slate-200 px-4 py-3 font-semibold uppercase text-slate-800 dark:bg-navy-800 dark:text-navy-100 lg:px-5">
                    Date
                   </th>
                   <th class="whitespace-nowrap bg-slate-200 px-4 py-3 font-semibold uppercase text-slate-800 dark:bg-navy-800 dark:text-navy-100 lg:px-5">
                    IP
                   </th>
                  
                </tr>
              </thead>
              <tbody>
                <?php $count = 0; ?>
                <?php $__currentLoopData = $userdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $count++; ?>
                <tr class="border-y border-transparent border-b-slate-200 dark:border-b-navy-500">
                  <td class="whitespace-nowrap px-4 py-3 sm:px-5"><?php echo e($count); ?></td>

                     <td class="whitespace-nowrap px-4 py-3 sm:px-5">
                      <?php echo e($user->trans_from); ?>

                     </td>
                      <td class="whitespace-nowrap px-4 py-3 sm:px-5">
                      <span class="text-primary">#<?php echo e($user->uid); ?></span>
                     </td>
                  <td class="whitespace-nowrap px-4 py-3 sm:px-5">
                   <?php echo e($user->amount); ?>

                  </td>
                  <td class="whitespace-nowrap px-4 py-3 sm:px-5">
                    <?php echo e(date('F j, Y, g:i a',$user->time)); ?>

                   </td>
                   <td class="whitespace-nowrap px-4 py-3 sm:px-5">
                    <?php echo e($user->ip); ?>

                   </td>

                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>


          <div class="flex flex-col justify-between space-y-4 px-4 py-4 sm:flex-row sm:items-center sm:space-y-0 sm:px-5">
              <?php echo e($userdata->links()); ?>

          </div>
        </div>

      </div>
    </main>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3)): ?>
<?php $component = $__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3; ?>
<?php unset($__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\playpoint_app\resources\views/admin/tracker.blade.php ENDPATH**/ ?>